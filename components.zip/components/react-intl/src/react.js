/* global React */
/* jshint esnext:true */

// TODO: Remove the global `React` binding lookup once the ES6 Module Transpiler
// supports external modules. This is a hack for now that provides the local
// modules a referece to React.
export default React;
